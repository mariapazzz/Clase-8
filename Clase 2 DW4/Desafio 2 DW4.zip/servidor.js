// const http=require('http');
//import http from 'http'
//const puerto = 3000;
//const server=http.createServer((req, res) =>{
   // console.log(req);
   // res.writeHead(200, {"Content-Type":"Text/plain"});
   // res.end("Hola Mundo");
//}

//)
//server.listen(puerto,()=> {
    //console.log(`Servidor corriendo en el puerto: ${puerto}`);
//}
//)
import express from 'express';
const app = express();
const puerto = 3000;
//Ruta Principal
app.get('/', (req, res) => {
res.send('¡Hola, mundo con Express! ');
});
//Iniciar el servidor
app.listen(puerto, () => {
console.log(`Servidor en funcionamiento en el puerto${puerto}`);
});